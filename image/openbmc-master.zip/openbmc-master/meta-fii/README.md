# meta-fii

Repository for storing metadata for OpenBMC
Fii USA crop

├── meta-fii
 └── meta-kudo
 └── meta-mori
