---
name: Question / Support
about: I have a question...
title: ''
labels: ''
assignees: ''

---

# STOP! READ BELOW.

We do not field questions or feature requests by Github Issues!

Questions or feature requests should be discussed on the mailing list or
Discord. Please see https://github.com/openbmc/openbmc#contact for info
on how to contact us.

Github Issues in openbmc/openbmc are for bugs only!
