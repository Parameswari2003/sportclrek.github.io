# *Hardware Name*

## Overview

*Brief summary of the hardware*

*Link to reference documentation*

## Building

*Any special steps required to build successfully beyond setting MACHINE*

*For example: corstone700 needs DISTRO=poky-tiny, musca only supports TF-M*

## Running

*A summary of how to deploy or execute the image*

*For example, an overview of the N1SDP SD structure, or FVP arguments*
