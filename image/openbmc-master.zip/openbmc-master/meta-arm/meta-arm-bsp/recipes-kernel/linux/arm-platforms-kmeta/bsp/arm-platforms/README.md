Arm platforms BSPs
==================

This directory contains Arm platforms definitions and configuration for Linux.
